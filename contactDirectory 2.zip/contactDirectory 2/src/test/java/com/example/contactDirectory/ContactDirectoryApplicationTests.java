package com.example.contactDirectory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactDirectoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
