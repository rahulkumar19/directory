package com.example.contactDirectory.repository;

import com.example.contactDirectory.model.Contact;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactRepository extends JpaRepository<Contact, Long> {
}
