package com.example.contactDirectory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactDirectoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactDirectoryApplication.class, args);
	}

}
